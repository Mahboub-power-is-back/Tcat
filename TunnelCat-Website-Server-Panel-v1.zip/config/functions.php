<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function parse_ports(string $raw): array
{
    $items = preg_split('/[\s,;]+/', trim($raw), -1, PREG_SPLIT_NO_EMPTY);
    $ports = [];

    foreach ($items as $item) {
        if (!ctype_digit($item)) {
            continue;
        }
        $port = (int)$item;
        if ($port >= 1 && $port <= 65535) {
            $ports[] = $port;
        }
    }

    return array_values(array_unique($ports));
}

function parse_protocols(string $raw): array
{
    $items = preg_split('/[\s,;]+/', strtoupper(trim($raw)), -1, PREG_SPLIT_NO_EMPTY);
    $valid = ['A','B','C','D','E','F','G'];
    $out = [];

    foreach ($items as $item) {
        if (in_array($item, $valid, true)) {
            $out[] = $item;
        }
    }

    return array_values(array_unique($out));
}

function parse_info(string $names, string $values): array
{
    $n = preg_split('/\R/', $names);
    $v = preg_split('/\R/', $values);
    $out = [];

    $max = max(count($n), count($v));

    for ($i = 0; $i < $max; $i++) {
        $name = trim($n[$i] ?? '');
        $value = trim($v[$i] ?? '');

        if ($name !== '') {
            $out[] = ['name' => $name, 'value' => $value];
        }
    }

    return $out;
}

function get_server(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM servers WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    return $row ?: null;
}

function server_to_api(array $s): array
{
    $ports = json_decode($s['ports'], true);
    $protocols = json_decode($s['protocols'], true);
    $info = json_decode($s['info_json'], true);

    if (!is_array($ports)) $ports = [];
    if (!is_array($protocols)) $protocols = [];
    if (!is_array($info)) $info = [];

    $protocolOutput = [];
    foreach ($protocols as $type) {
        $protocolOutput[] = [
            'type' => $type,
            'port' => $ports
        ];
    }

    return [
        'name' => $s['name'],
        'ip_addr' => $s['ip_addr'],
        'domain' => $s['domain'],
        'flag' => $s['flag'],
        'ovpn_key' => $s['ovpn_key'],
        'ovpn_options' => $s['ovpn_options'],
        'port' => $ports,
        'info' => $info,
        'protocol' => $protocolOutput
    ];
}

function repository_json(): string
{
    $stmt = db()->query(
        'SELECT * FROM servers WHERE enabled = 1 ORDER BY sort_order ASC, id ASC'
    );

    $servers = [];
    foreach ($stmt->fetchAll() as $server) {
        $servers[] = server_to_api($server);
    }

    $now = time();

    $payload = [
        'server_data_version' => '1',
        'ads_disabled' => true,
        'release_timestamp' => $now,
        'data_information' => 'TunnelCat custom server repository',
        'data_logo_image' => '',
        'data_bottom_image' => '',
        'servers' => $servers
    ];

    return json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
}
