<?php
declare(strict_types=1);

const APP_NAME = 'TunnelCat Server Panel';
const DB_FILE = __DIR__ . '/../data/panel.sqlite';
const SESSION_NAME = 'tunnelcat_panel';
const REPOSITORY_NAME = '@official';

/*
 * Change this after deployment if your panel is behind a reverse proxy.
 * Leave empty to auto-detect the current host.
 */
const PUBLIC_BASE_URL = '';

date_default_timezone_set('UTC');
