# Deployment

## Apache

Point the document root at:

`TunnelCat-Website-Server-Panel/public`

Enable `mod_rewrite` and make the `data/` directory writable.

The `.htaccess` maps:

- `/@official` -> `api.php`
- `/@official/check` -> `check.php`

## Nginx

Use a `try_files` fallback to `index.php` and add explicit rewrites:

```nginx
location = /@official {
    rewrite ^ /api.php last;
}
location = /@official/check {
    rewrite ^ /check.php last;
}
```

The PHP process must be able to write to `data/panel.sqlite`.

## First setup

Open:

`/install.php`

Create the administrator, then remove `public/install.php`.
