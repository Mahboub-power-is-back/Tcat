<?php
require_once __DIR__ . '/../config/auth.php';
logout_admin();
header('Location: /login.php');
exit;
