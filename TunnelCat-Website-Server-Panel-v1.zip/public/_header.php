<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/functions.php';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($title ?? APP_NAME) ?></title>
<style>
:root{font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#f3f5f7;color:#17202a}
body{margin:0}.nav{background:#111827;color:#fff;padding:14px 20px;display:flex;gap:18px;align-items:center}
.nav a{color:#fff;text-decoration:none}.wrap{max-width:1050px;margin:28px auto;padding:0 16px}
.card{background:#fff;border-radius:14px;padding:20px;margin-bottom:18px;box-shadow:0 2px 12px #00000012}
h1,h2{margin-top:0}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
label{font-weight:600;display:block;margin-bottom:6px}input,textarea,select{width:100%;box-sizing:border-box;padding:11px;border:1px solid #cbd5e1;border-radius:9px}
textarea{min-height:120px;font-family:monospace}.full{grid-column:1/-1}
.btn{display:inline-block;border:0;border-radius:9px;padding:10px 15px;background:#2563eb;color:#fff;text-decoration:none;cursor:pointer}
.btn.danger{background:#dc2626}.btn.gray{background:#64748b}.btn.green{background:#059669}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:11px;border-bottom:1px solid #e5e7eb}
.badge{padding:4px 8px;border-radius:999px;background:#dcfce7;color:#166534;font-size:12px}
.badge.off{background:#fee2e2;color:#991b1b}
.notice{padding:12px;border-radius:9px;background:#eff6ff;color:#1e40af}
.error{padding:12px;border-radius:9px;background:#fee2e2;color:#991b1b}
.actions{display:flex;gap:8px;flex-wrap:wrap}
@media(max-width:700px){.grid{grid-template-columns:1fr}.full{grid-column:auto}}
</style>
</head>
<body>
<div class="nav">
<strong><?= h(APP_NAME) ?></strong>
<?php if (is_logged_in()): ?>
<a href="/">Servers</a>
<a href="/server.php">Add server</a>
<a href="/api.php?download=1">JSON</a>
<a href="/logout.php">Logout</a>
<?php endif; ?>
</div>
<div class="wrap">
