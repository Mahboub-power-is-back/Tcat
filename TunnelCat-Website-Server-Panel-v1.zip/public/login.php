<?php
require_once __DIR__ . '/../config/auth.php';

if (is_logged_in()) {
    header('Location: /');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (login_admin(trim($_POST['username'] ?? ''), $_POST['password'] ?? '')) {
        header('Location: /');
        exit;
    }
    $error = 'Invalid username or password.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login</title>
<style>body{font-family:system-ui;background:#f3f5f7}.box{max-width:400px;margin:80px auto;background:#fff;padding:28px;border-radius:14px}input{width:100%;box-sizing:border-box;padding:12px;margin:8px 0 16px}button{padding:12px 18px;background:#2563eb;color:#fff;border:0;border-radius:8px}</style>
</head><body><div class="box">
<h1>TunnelCat Panel</h1>
<?php if ($error): ?><p style="color:#b91c1c"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<form method="post">
<label>Username</label><input name="username" required>
<label>Password</label><input name="password" type="password" required>
<button>Login</button>
</form>
</div></body></html>
