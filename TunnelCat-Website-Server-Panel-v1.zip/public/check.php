<?php
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$stmt = db()->query('SELECT MAX(updated_at) AS updated_at, COUNT(*) AS server_count FROM servers WHERE enabled=1');
$row = $stmt->fetch();

echo json_encode([
    'server_data_version' => '1',
    'release_timestamp' => time(),
    'updated_at' => $row['updated_at'],
    'server_count' => (int)$row['server_count']
], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
