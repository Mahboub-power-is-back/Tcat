<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/functions.php';
require_login();

$title = 'Servers';
$stmt = db()->query('SELECT * FROM servers ORDER BY sort_order ASC, id ASC');
$servers = $stmt->fetchAll();

require __DIR__ . '/_header.php';
?>
<div class="card">
<h1>Server Repository</h1>
<p>Manage the servers published by your TunnelCat repository.</p>
<div class="actions">
<a class="btn" href="/server.php">+ Add server</a>
<a class="btn green" href="/api.php?download=1">Download JSON</a>
</div>
</div>

<div class="card">
<table>
<thead><tr><th>Name</th><th>Host</th><th>Ports</th><th>Protocols</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach ($servers as $s): ?>
<tr>
<td><?= h($s['name']) ?></td>
<td><?= h($s['domain'] ?: $s['ip_addr']) ?></td>
<td><?= h(implode(', ', json_decode($s['ports'], true) ?: [])) ?></td>
<td><?= h(implode(', ', json_decode($s['protocols'], true) ?: [])) ?></td>
<td>
<?php if ((int)$s['enabled']): ?><span class="badge">Enabled</span>
<?php else: ?><span class="badge off">Disabled</span><?php endif; ?>
</td>
<td>
<div class="actions">
<a class="btn gray" href="/server.php?id=<?= (int)$s['id'] ?>">Edit</a>
<form method="post" action="/delete.php" onsubmit="return confirm('Delete this server?')">
<input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
<input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
<button class="btn danger" type="submit">Delete</button>
</form>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php if (!$servers): ?>
<tr><td colspan="6">No servers yet.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>

<div class="card">
<h2>Public repository endpoints</h2>
<div class="notice">
<code>/@official</code> — server JSON<br>
<code>/@official/check</code> — repository metadata
</div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
