<?php
require_once __DIR__ . '/../config/db.php';

if (db()->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0) {
    exit('Already installed. Delete install.php.');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || strlen($password) < 8) {
        $error = 'Username is required and password must be at least 8 characters.';
    } else {
        $stmt = db()->prepare(
            'INSERT INTO admins(username,password_hash,created_at) VALUES(?,?,?)'
        );
        $stmt->execute([
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            gmdate('c')
        ]);
        header('Location: /login.php');
        exit;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Install</title>
<style>body{font-family:system-ui;max-width:500px;margin:50px auto;padding:20px}input{width:100%;padding:12px;margin:7px 0 14px;box-sizing:border-box}button{padding:12px 18px}</style>
</head><body>
<h1>TunnelCat Panel Setup</h1>
<?php if ($error): ?><p style="color:#b91c1c"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<form method="post">
<label>Admin username</label>
<input name="username" required>
<label>Admin password</label>
<input name="password" type="password" minlength="8" required>
<button>Create admin</button>
</form>
<p>After installation, delete <code>install.php</code>.</p>
</body></html>
