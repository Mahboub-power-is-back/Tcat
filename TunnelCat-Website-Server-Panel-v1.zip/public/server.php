<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/functions.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$server = $id ? get_server($id) : null;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf'] ?? null);

    $name = trim($_POST['name'] ?? '');
    $ip = trim($_POST['ip_addr'] ?? '');
    $domain = trim($_POST['domain'] ?? '');
    $flag = trim($_POST['flag'] ?? '');
    $ovpnKey = trim($_POST['ovpn_key'] ?? '');
    $ovpnOptions = trim($_POST['ovpn_options'] ?? '');
    $ports = parse_ports($_POST['ports'] ?? '');
    $protocols = parse_protocols($_POST['protocols'] ?? '');
    $info = parse_info($_POST['info_names'] ?? '', $_POST['info_values'] ?? '');
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    $sortOrder = (int)($_POST['sort_order'] ?? 0);

    if ($name === '' || $ip === '') {
        $error = 'Server name and IP/host are required.';
    } elseif (!$ports) {
        $error = 'At least one valid port is required.';
    } elseif (!$protocols) {
        $error = 'At least one protocol A-G is required.';
    } else {
        $now = gmdate('c');

        if ($id && $server) {
            $stmt = db()->prepare('
                UPDATE servers SET
                name=?, ip_addr=?, domain=?, flag=?, ovpn_key=?, ovpn_options=?,
                ports=?, protocols=?, info_json=?, enabled=?, sort_order=?, updated_at=?
                WHERE id=?
            ');
            $stmt->execute([
                $name, $ip, $domain, $flag, $ovpnKey, $ovpnOptions,
                json_encode($ports), json_encode($protocols), json_encode($info),
                $enabled, $sortOrder, $now, $id
            ]);
        } else {
            $stmt = db()->prepare('
                INSERT INTO servers
                (name,ip_addr,domain,flag,ovpn_key,ovpn_options,ports,protocols,info_json,enabled,sort_order,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            ');
            $stmt->execute([
                $name, $ip, $domain, $flag, $ovpnKey, $ovpnOptions,
                json_encode($ports), json_encode($protocols), json_encode($info),
                $enabled, $sortOrder, $now, $now
            ]);
        }

        header('Location: /');
        exit;
    }
}

if (!$server) {
    $server = [
        'name'=>'',
        'ip_addr'=>'',
        'domain'=>'',
        'flag'=>'',
        'ovpn_key'=>'',
        'ovpn_options'=>'',
        'ports'=>'[53]',
        'protocols'=>'["F"]',
        'info_json'=>'[]',
        'enabled'=>1,
        'sort_order'=>0
    ];
}

$ports = json_decode($server['ports'], true) ?: [];
$protocols = json_decode($server['protocols'], true) ?: [];
$info = json_decode($server['info_json'], true) ?: [];
$infoNames = implode("\n", array_column($info, 'name'));
$infoValues = implode("\n", array_column($info, 'value'));

$title = $id ? 'Edit Server' : 'Add Server';
require __DIR__ . '/_header.php';
?>
<div class="card">
<h1><?= h($title) ?></h1>

<?php if ($error): ?><div class="error"><?= h($error) ?></div><br><?php endif; ?>

<form method="post">
<input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

<div class="grid">
<div>
<label>Server name</label>
<input name="name" value="<?= h($server['name']) ?>" required>
</div>

<div>
<label>IP / Host</label>
<input name="ip_addr" value="<?= h($server['ip_addr']) ?>" required>
</div>

<div>
<label>Domain</label>
<input name="domain" value="<?= h($server['domain']) ?>" placeholder="optional">
</div>

<div>
<label>Flag</label>
<input name="flag" value="<?= h($server['flag']) ?>" placeholder="e.g. tn">
</div>

<div>
<label>Ports</label>
<input name="ports" value="<?= h(implode(', ', $ports)) ?>" placeholder="53, 80, 443" required>
</div>

<div>
<label>Protocols</label>
<input name="protocols" value="<?= h(implode(', ', $protocols)) ?>" placeholder="F, G">
</div>

<div>
<label>Sort order</label>
<input type="number" name="sort_order" value="<?= (int)$server['sort_order'] ?>">
</div>

<div>
<label>Enabled</label>
<div style="padding:10px 0">
<input style="width:auto" type="checkbox" name="enabled" <?= (int)$server['enabled'] ? 'checked' : '' ?>>
Publish this server
</div>
</div>

<div class="full">
<label>OpenVPN key</label>
<textarea name="ovpn_key" placeholder="Base64/encrypted OVPN key data"><?= h($server['ovpn_key']) ?></textarea>
</div>

<div class="full">
<label>OpenVPN options</label>
<textarea name="ovpn_options" placeholder="OpenVPN option text"><?= h($server['ovpn_options']) ?></textarea>
</div>

<div>
<label>Info names — one per line</label>
<textarea name="info_names" placeholder="Location&#10;Network"><?= h($infoNames) ?></textarea>
</div>

<div>
<label>Info values — one per line</label>
<textarea name="info_values" placeholder="Tunisia&#10;Fast DNS"><?= h($infoValues) ?></textarea>
</div>
</div>

<br>
<button class="btn" type="submit">Save server</button>
<a class="btn gray" href="/">Cancel</a>
</form>
</div>

<div class="card">
<h2>Protocol reference</h2>
<p>A = Direct, B = HTTP Injection, C = HTTP Tunneling, D = OpenHTTP Puncher,
E = SSL Tunnel, F = Fast DNS, G = Slow DNS.</p>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
