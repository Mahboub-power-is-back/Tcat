<?php
require_once __DIR__ . '/../config/functions.php';

header('X-Content-Type-Options: nosniff');

if (isset($_GET['download'])) {
    $json = repository_json();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="server_data.json"');
    echo $json;
    exit;
}

header('Content-Type: application/json; charset=utf-8');
echo repository_json();
