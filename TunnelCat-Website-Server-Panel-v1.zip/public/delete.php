<?php
require_once __DIR__ . '/../config/auth.php';
require_login();
verify_csrf($_POST['csrf'] ?? null);

$id = (int)($_POST['id'] ?? 0);
if ($id > 0) {
    $stmt = db()->prepare('DELETE FROM servers WHERE id=?');
    $stmt->execute([$id]);
}
header('Location: /');
exit;
