# TunnelCat Website Server Panel

A small self-hosted PHP 8 + SQLite server panel for managing TunnelCat server
definitions.

## What it does

- Admin login
- Add / edit / delete servers
- Server name, IP/host, domain, port list and flag
- Tunnel protocol list: A-G
- OpenVPN key/options fields
- Extra server information fields
- Enable/disable servers
- Generates the exact JSON field structure used by the TunnelCat Android
  `ConfigurationManager.loadServers()` code
- Public repository endpoint:
  - `/@official`
  - `/@official/check`
- JSON download from the dashboard
- No MySQL required

## Install

Requirements:
- PHP 8.0+
- PDO SQLite enabled
- Apache/Nginx configured to serve `public/`

1. Copy the project to your website.
2. Make `data/` writable by PHP:
   `chmod 775 data`
3. Open `/install.php` once.
4. Create the admin account.
5. Delete `install.php`.
6. Login at `/`.
7. Add your servers.

## Important

This first version intentionally exposes the server data as JSON. The current
TunnelCat Android source decrypts its remote repository response using a legacy
encryption routine. We should first validate the panel/database/schema, then
implement the exact compatible encryption and change the Android repository URL.

Do not put passwords or private keys into the public `info` fields.
