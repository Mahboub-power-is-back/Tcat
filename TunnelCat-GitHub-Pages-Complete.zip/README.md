# TunnelCat GitHub Pages

This package is a GitHub Pages edition of the uploaded `TunnelCat-Repository-Panel-GitHub.zip`.

## What changed

The original project is PHP + SQLite. GitHub Pages cannot execute PHP, so this package keeps the original PHP project under `source-php/` and adds a static GitHub Pages implementation under `docs/`.

The Pages version provides:

- Public TunnelCat repository landing page.
- Browser-side repository/server editor.
- Export of `repository.json` and `servers.json`.
- AES-256-CBC generation compatible with the legacy TunnelCat repository format.
- GitHub Actions generation of the encrypted `repo/<username>` endpoint.
- Automatic GitHub Pages deployment.

## Important

The browser admin editor is **not a server-side secure admin panel**. GitHub Pages is static. It saves edits in the browser and can export files, but it cannot directly write changes back to GitHub without a GitHub API token. Do not put a GitHub token into this page.

For persistent changes:

1. Open `data/repository.json` in GitHub and edit it.
2. Open `data/servers.json` in GitHub and edit it.
3. Commit the changes to `main` (or `master`).
4. The Pages workflow runs `scripts/build_repo.py`.
5. The workflow generates `docs/repo/<username>`.
6. GitHub Pages deploys the result.

## Enable GitHub Pages

In the repository:

**Settings → Pages → Source: GitHub Actions**

Then run:

**Actions → Deploy TunnelCat GitHub Pages → Run workflow**

After deployment, GitHub will show a URL similar to:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`

The TunnelCat repository endpoint will be:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/repo/official`

Use that full URL if the TunnelCat client asks for a repository URL. If the client asks only for a repository username, use `official` according to its original repository mechanism.

## Server data

`data/servers.json` accepts objects like:

```json
[
  {
    "name": "Fast DNS",
    "ip_addr": "example.com",
    "domain": "",
    "flag": "TN",
    "ovpn_key": "",
    "ovpn_options": "",
    "ports": "53",
    "protocols": "F",
    "info": "Protocol=Fast DNS\nPort=53",
    "sort_order": 0
  }
]
```

Protocol `F` is the legacy TunnelCat Fast DNS protocol. Other legacy values `A` through `G` are accepted.

## Compatibility

The legacy AES key is taken from the exact uploaded PHP source rather than invented. The generated payload keeps the original format: 16 filler bytes followed by the UTF-8 JSON, encrypted with AES-256-CBC and Base64 encoded.

## Source preservation

The original uploaded PHP panel is preserved in:

`source-php/`

It is not executed by GitHub Pages.
