
const KEY_B64="daObvHqoIwC8H1eBTYI+2IourqIlzmDYio2+3dRrsrk=";
const LS="tunnelcat-pages-v1";
let state={repo:{username:"official",title:"Official",version:"1",data_information:"GitHub Pages TunnelCat repository",ads_disabled:false,logo_image:"",bottom_image:""},servers:[]};

function msg(text,kind="ok"){document.getElementById("msg").innerHTML=`<div class="notice ${kind}">${escapeHtml(text)}</div>`}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function saveLS(){localStorage.setItem(LS,JSON.stringify(state))}
function loadLS(){try{const x=JSON.parse(localStorage.getItem(LS)||"null");if(x?.repo&&Array.isArray(x.servers))state=x}catch(e){}}
function fieldsToState(){state.repo={username:v("username")||"official",title:v("title")||"Official",version:v("version")||"1",data_information:v("data_information"),ads_disabled:document.getElementById("ads_disabled").checked,logo_image:v("logo_image"),bottom_image:v("bottom_image")}}
function stateToFields(){for(const k of ["username","title","version","data_information","logo_image","bottom_image"])document.getElementById(k).value=state.repo[k]??"";document.getElementById("ads_disabled").checked=!!state.repo.ads_disabled}
function v(id){return document.getElementById(id).value}
function showTab(id){for(const x of ["repo","servers","output"])document.getElementById(x).style.display=x===id?"block":"none";for(const x of ["repoTab","serverTab","outputTab"])document.getElementById(x).classList.toggle("active",x.toLowerCase().startsWith(id==="repo"?"repo":id==="servers"?"server":"output"))}
function saveAll(){fieldsToState();saveLS();renderServers();msg("Saved in this browser. Export the JSON files before publishing to GitHub.");}
function resetAll(){if(confirm("Reset the local editor to the default data?")){localStorage.removeItem(LS);state={repo:{username:"official",title:"Official",version:"1",data_information:"GitHub Pages TunnelCat repository",ads_disabled:false,logo_image:"",bottom_image:""},servers:[]};stateToFields();renderServers();msg("Local data reset.")}}
function addServer(){state.servers.push({name:"New Server",ip_addr:"",domain:"",flag:"",ovpn_key:"",ovpn_options:"",ports:"53",protocols:"F",info:"",sort_order:state.servers.length});saveLS();renderServers();showTab("servers")}
function removeServer(i){if(confirm("Delete this server?")){state.servers.splice(i,1);saveLS();renderServers()}}
function renderServers(){
 const el=document.getElementById("serverList");
 if(!state.servers.length){el.innerHTML='<p class="muted">No servers yet. Add one above.</p>';return}
 el.innerHTML=state.servers.map((s,i)=>`<div class="server">
 <div class="serverhead"><b>Server ${i+1}</b><button class="danger" onclick="removeServer(${i})">Delete</button></div>
 <div class="grid">
 <div><label>Name</label><input data-i="${i}" data-k="name" value="${escapeHtml(s.name)}"></div>
 <div><label>IP / Host</label><input data-i="${i}" data-k="ip_addr" value="${escapeHtml(s.ip_addr)}"></div>
 <div><label>Domain</label><input data-i="${i}" data-k="domain" value="${escapeHtml(s.domain)}"></div>
 <div><label>Flag</label><input data-i="${i}" data-k="flag" placeholder="TN" value="${escapeHtml(s.flag)}"></div>
 <div><label>Ports</label><input data-i="${i}" data-k="ports" placeholder="53,80,443" value="${escapeHtml(s.ports)}"></div>
 <div><label>Protocols</label><input data-i="${i}" data-k="protocols" placeholder="F" value="${escapeHtml(s.protocols)}"></div>
 <div><label>OVPN Key</label><textarea data-i="${i}" data-k="ovpn_key">${escapeHtml(s.ovpn_key)}</textarea></div>
 <div><label>OVPN Options</label><textarea data-i="${i}" data-k="ovpn_options">${escapeHtml(s.ovpn_options)}</textarea></div>
 </div>
 <label>Server info (one name=value per line)</label><textarea data-i="${i}" data-k="info">${escapeHtml(s.info)}</textarea>
 <label>Sort order</label><input type="number" data-i="${i}" data-k="sort_order" value="${Number(s.sort_order)||0}">
 </div>`).join("");
 el.querySelectorAll("[data-i]").forEach(x=>x.addEventListener("input",()=>{let i=+x.dataset.i,k=x.dataset.k;state.servers[i][k]=k==="sort_order"?Number(x.value)||0:x.value;saveLS()}))
}
function parsePorts(raw){return [...new Set(String(raw||"").trim().split(/[,\s]+/).filter(x=>/^\d+$/.test(x)).map(Number).filter(n=>n>=1&&n<=65535))]}
function parseProtocols(raw){const a=["A","B","C","D","E","F","G"],out=[];for(const p of String(raw||"").toUpperCase().trim().split(/[,\s]+/)){if(a.includes(p)&&!out.includes(p))out.push(p)}return out.length?out:["F"]}
function parseInfo(raw){const out=[];for(const line of String(raw||"").split(/\r?\n/)){const p=line.split("=");if(p.length>=2)out.push({name:p.shift().trim(),value:p.join("=").trim()})}return out}
function buildPayload(){fieldsToState();const servers=[...state.servers].sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)).map(s=>{const ports=parsePorts(s.ports),protocol=parseProtocols(s.protocols).map(type=>({type,port:ports}));return {name:s.name||"",ip_addr:s.ip_addr||"",domain:s.domain||"",flag:s.flag||"",ovpn_key:s.ovpn_key||"",ovpn_options:s.ovpn_options||"",port:ports,info:parseInfo(s.info),protocol}});return {server_data_version:String(state.repo.version||"1"),release_timestamp:Math.floor(Date.now()/1000),data_information:state.repo.data_information||"",data_logo_image:state.repo.logo_image||"",data_bottom_image:state.repo.bottom_image||"",ads_disabled:!!state.repo.ads_disabled,servers}}
function b64ToBytes(b){const bin=atob(b),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a}
function bytesToB64(a){let s="";for(let i=0;i<a.length;i+=0x8000)s+=String.fromCharCode(...a.subarray(i,i+0x8000));return btoa(s)}
async function encryptPayload(payload){const key=await crypto.subtle.importKey("raw",b64ToBytes(KEY_B64),{name:"AES-CBC"},false,["encrypt"]);const json=new TextEncoder().encode(JSON.stringify(payload));const plain=new Uint8Array(16+json.length);plain.set(json,16);const cipher=await crypto.subtle.encrypt({name:"AES-CBC",iv:new Uint8Array(16)},key,plain);return bytesToB64(new Uint8Array(cipher))}
function download(name,text,type="application/json"){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function downloadRepository(){fieldsToState();saveLS();download("repository.json",JSON.stringify(state.repo,null,2))}
function downloadServers(){fieldsToState();saveLS();download("servers.json",JSON.stringify(state.servers,null,2))}
async function generateEndpoint(){try{fieldsToState();saveLS();const payload=buildPayload(),enc=await encryptPayload(payload);document.getElementById("endpointBox").innerHTML=`<label>Encrypted server_data</label><textarea id="endpointText" readonly>${escapeHtml(enc)}</textarea><div class="actions"><button onclick="download('official',document.getElementById('endpointText').value,'text/plain')">Download official endpoint</button><button class="secondary" onclick="navigator.clipboard?.writeText(document.getElementById('endpointText').value);msg('Copied encrypted endpoint.')">Copy</button></div>`;msg("Encrypted endpoint generated. Commit the downloaded file as repo/official, or let GitHub Actions generate it from data/*.json.");showTab("output")}catch(e){msg("Could not generate endpoint: "+e,"error")}}
loadLS();stateToFields();renderServers();document.getElementById("repoUrl").textContent="repo/"+(state.repo.username||"official");
