<?php
declare(strict_types=1);

const APP_NAME = 'TunnelCat Repository Panel';
const DB_FILE = __DIR__ . '/../storage/panel.sqlite';

// Legacy TunnelCat AES key from Constants.KEY, decoded from Base64.
const TUNNELCAT_AES_KEY_B64 = 'daObvHqoIwC8H1eBTYI+2IourqIlzmDYio2+3dRrsrk=';

// Default repository username.
const DEFAULT_REPO_USERNAME = 'official';

// Change this hash before production. Generate one with:
// php -r "echo password_hash('YOUR_PASSWORD', PASSWORD_DEFAULT), PHP_EOL;"
const ADMIN_PASSWORD_HASH = '$2y$10$8l9L2lQv4w8v8y6j7Q0xQO8g5uQ3zW7m1m6m0y1h9s8a3k7n5bQyK';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dir = dirname(DB_FILE);
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $pdo = new PDO('sqlite:' . DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('CREATE TABLE IF NOT EXISTS repositories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL DEFAULT "TunnelCat Repository",
        version TEXT NOT NULL DEFAULT "1",
        data_information TEXT NOT NULL DEFAULT "",
        ads_disabled INTEGER NOT NULL DEFAULT 0,
        logo_image TEXT NOT NULL DEFAULT "",
        bottom_image TEXT NOT NULL DEFAULT "",
        release_timestamp INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )');
    $pdo->exec('CREATE TABLE IF NOT EXISTS servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        repository_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        ip_addr TEXT NOT NULL DEFAULT "",
        domain TEXT NOT NULL DEFAULT "",
        flag TEXT NOT NULL DEFAULT "",
        ovpn_key TEXT NOT NULL DEFAULT "",
        ovpn_options TEXT NOT NULL DEFAULT "",
        ports TEXT NOT NULL DEFAULT "53",
        info_json TEXT NOT NULL DEFAULT "[]",
        protocols TEXT NOT NULL DEFAULT "F",
        sort_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(repository_id) REFERENCES repositories(id) ON DELETE CASCADE
    )');
    $count = (int)$pdo->query('SELECT COUNT(*) FROM repositories')->fetchColumn();
    if ($count === 0) {
        $s = $pdo->prepare('INSERT INTO repositories(username,title,version,data_information,release_timestamp) VALUES(?,?,?,?,?)');
        $s->execute([DEFAULT_REPO_USERNAME, 'Official', '1', 'Initial repository', time()]);
    }
    return $pdo;
}

db();

function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function csrf(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400); exit('Invalid CSRF token');
    }
}
function require_login(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['admin'])) { header('Location: /admin/login.php'); exit; }
}
function redirect(string $url): never { header('Location: ' . $url); exit; }
function repository_by_username(string $username): ?array {
    $s = db()->prepare('SELECT * FROM repositories WHERE username = ? LIMIT 1');
    $s->execute([$username]);
    $r = $s->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
}
function parse_ports(string $raw): array {
    $out = [];
    foreach (preg_split('/[,\s]+/', trim($raw)) as $p) {
        if ($p === '') continue;
        if (ctype_digit($p)) {
            $n = (int)$p;
            if ($n >= 1 && $n <= 65535) $out[] = $n;
        }
    }
    return array_values(array_unique($out));
}
function parse_protocols(string $raw): array {
    $allowed = ['A','B','C','D','E','F','G'];
    $out = [];
    foreach (preg_split('/[,\s]+/', strtoupper(trim($raw))) as $p) {
        if (in_array($p, $allowed, true) && !in_array($p, $out, true)) $out[] = $p;
    }
    return $out ?: ['F'];
}
function parse_info(string $raw): array {
    $raw = trim($raw);
    if ($raw === '') return [];
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $out = [];
        foreach ($decoded as $row) {
            if (is_array($row) && isset($row['name'], $row['value'])) {
                $out[] = ['name' => (string)$row['name'], 'value' => (string)$row['value']];
            }
        }
        return $out;
    }
    $out = [];
    foreach (preg_split('/\r?\n/', $raw) as $line) {
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) $out[] = ['name' => trim($parts[0]), 'value' => trim($parts[1])];
    }
    return $out;
}
function build_payload(array $repo, array $servers): array {
    $payloadServers = [];
    foreach ($servers as $s) {
        $ports = parse_ports($s['ports']);
        $protocols = parse_protocols($s['protocols']);
        $protoObjects = [];
        foreach ($protocols as $p) $protoObjects[] = ['type' => $p, 'port' => $ports];
        $payloadServers[] = [
            'name' => $s['name'],
            'ip_addr' => $s['ip_addr'],
            'domain' => $s['domain'],
            'flag' => $s['flag'],
            'ovpn_key' => $s['ovpn_key'],
            'ovpn_options' => $s['ovpn_options'],
            'port' => $ports,
            'info' => parse_info($s['info_json']),
            'protocol' => $protoObjects,
        ];
    }
    return [
        'server_data_version' => (string)$repo['version'],
        'release_timestamp' => (int)$repo['release_timestamp'],
        'data_information' => (string)$repo['data_information'],
        'data_logo_image' => (string)$repo['logo_image'],
        'data_bottom_image' => (string)$repo['bottom_image'],
        'ads_disabled' => ((int)$repo['ads_disabled']) === 1,
        'servers' => $payloadServers,
    ];
}
function encrypt_for_tunnelcat(string $json): string {
    $key = base64_decode(TUNNELCAT_AES_KEY_B64, true);
    if ($key === false || strlen($key) !== 32) throw new RuntimeException('Invalid AES key');
    // The Android client throws away the first decrypted 16-byte block.
    // We therefore put filler in block 1 and JSON beginning at block 2.
    $plaintext = str_repeat("\0", 16) . $json;
    $iv = str_repeat("\0", 16);
    $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) throw new RuntimeException('Encryption failed');
    return base64_encode($cipher);
}
function encrypted_payload(array $repo, array $servers): string {
    $json = json_encode(build_payload($repo, $servers), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) throw new RuntimeException('JSON encoding failed');
    return encrypt_for_tunnelcat($json);
}
