# TunnelCat Repository Panel

A small PHP 8+ web panel that publishes server data for the legacy TunnelCat Android client.

## What it does

- Admin login
- Add/edit/delete repositories
- Add/edit/delete servers
- Publish `server_data` JSON
- AES-256-CBC compatible response format for the legacy Android `CryptoUtility.decryptB64()` implementation
- `/repo/<username>` endpoint
- `/repo/<username>/check` endpoint
- SQLite database; no MySQL required

## Important compatibility detail

The Android client decrypts the Base64 response with a random IV and discards the first 16 decrypted bytes. Therefore the publisher intentionally encrypts:

`16-byte filler + JSON`

with AES-256-CBC. The first decrypted block is IV-dependent garbage, while the JSON begins in block 2 and decrypts correctly regardless of the client's random IV.

The AES key is the legacy TunnelCat `Constants.KEY` value. Change it in `app/config.php` only if your APK uses a different key.

## Install

Requirements: PHP 8.0+, PDO SQLite, OpenSSL, Apache or Nginx.

1. Copy this directory to your web server.
2. Point the web root at `public/`.
3. Make `storage/` writable by PHP.
4. Edit `app/config.php` and set the admin password hash and repository username.
5. Open `/admin/login.php`.

Default admin password in this package is `change-me-now`. Change it before exposing the panel.

## URLs

If your domain is `https://example.com` and repository username is `myrepo`:

- Admin: `https://example.com/admin/login.php`
- Repository: `https://example.com/repo/myrepo`
- Check: `https://example.com/repo/myrepo/check`

The legacy app's custom repository field should contain the username, e.g. `myrepo`.

## Server JSON fields

The panel publishes the fields used by the original `ConfigurationManager`: name, ip_addr, domain, flag, ovpn_key, ovpn_options, port, info and protocol.

Protocol `F` is Fast DNS. Other legacy protocol values are accepted as raw values.
