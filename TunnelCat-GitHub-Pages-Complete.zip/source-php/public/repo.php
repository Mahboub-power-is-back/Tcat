<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config.php';
$username = trim((string)($_GET['username'] ?? ''));
if ($username === '' || !preg_match('/^[A-Za-z0-9_.@-]+$/', $username)) { http_response_code(404); exit; }
$repo = repository_by_username($username);
if (!$repo) { http_response_code(404); exit; }
$s = db()->prepare('SELECT * FROM servers WHERE repository_id = ? ORDER BY sort_order ASC, id ASC');
$s->execute([(int)$repo['id']]);
$servers = $s->fetchAll(PDO::FETCH_ASSOC);
try {
    $body = encrypted_payload($repo, $servers);
    header('Content-Type: text/plain; charset=UTF-8');
    header('Cache-Control: no-store, max-age=0');
    echo $body;
} catch (Throwable $e) { http_response_code(500); echo 'error'; }
