<?php
require_once __DIR__ . '/../app/config.php';
header('Location: /admin/login.php');
