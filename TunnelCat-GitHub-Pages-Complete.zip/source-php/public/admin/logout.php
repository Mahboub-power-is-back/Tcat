<?php
require_once __DIR__ . '/../../app/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
session_destroy(); header('Location: /admin/login.php'); exit;
