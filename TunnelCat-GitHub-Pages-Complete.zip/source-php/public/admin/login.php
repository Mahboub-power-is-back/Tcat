<?php
require_once __DIR__ . '/../../app/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!empty($_SESSION['admin'])) { header('Location: /admin/index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) $error = 'Invalid request';
    elseif (password_verify((string)$_POST['password'], ADMIN_PASSWORD_HASH)) {
        session_regenerate_id(true); $_SESSION['admin'] = true; header('Location: /admin/index.php'); exit;
    } else $error = 'Invalid password';
}
$token = csrf();
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><link rel="stylesheet" href="/admin/style.css"></head><body><main class="box"><h1>TunnelCat Panel</h1><p>Repository administration</p><?php if($error): ?><div class="error"><?=h($error)?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?=h($token)?>"><label>Password</label><input type="password" name="password" required autofocus><button>Login</button></form></main></body></html>
