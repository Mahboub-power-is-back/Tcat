#!/usr/bin/env python3
import base64, json, os, re, subprocess, tempfile, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
REPO_DIR = DOCS / "repo"
REPO_DIR.mkdir(parents=True, exist_ok=True)

CONFIG = ROOT / "source-php" / "app" / "config.php"
text = CONFIG.read_text(encoding="utf-8")
m = re.search(r"TUNNELCAT_AES_KEY_B64\s*=\s*'([^']+)'", text)
if not m:
    raise SystemExit("TunnelCat AES key not found in preserved source.")
key_b64 = m.group(1)
key = base64.b64decode(key_b64)
if len(key) != 32:
    raise SystemExit("TunnelCat AES key is not 32 bytes.")

repo_file = ROOT / "data" / "repository.json"
servers_file = ROOT / "data" / "servers.json"
repo = json.loads(repo_file.read_text(encoding="utf-8"))
servers = json.loads(servers_file.read_text(encoding="utf-8"))

username = str(repo.get("username", "official")).strip()
if not re.fullmatch(r"[A-Za-z0-9_.@-]+", username):
    raise SystemExit("Invalid repository username.")

def ports(raw):
    if isinstance(raw, list):
        vals = raw
    else:
        vals = re.split(r"[,\s]+", str(raw or "").strip())
    out=[]
    for x in vals:
        if str(x).isdigit():
            n=int(x)
            if 1 <= n <= 65535 and n not in out:
                out.append(n)
    return out

def protocols(raw):
    allowed=list("ABCDEFG")
    out=[]
    for p in re.split(r"[,\s]+", str(raw or "").upper().strip()):
        if p in allowed and p not in out:
            out.append(p)
    return out or ["F"]

def info(raw):
    if isinstance(raw, list):
        return [{"name":str(x.get("name","")), "value":str(x.get("value",""))}
                for x in raw if isinstance(x,dict) and "name" in x and "value" in x]
    out=[]
    for line in str(raw or "").splitlines():
        if "=" in line:
            n,v=line.split("=",1)
            out.append({"name":n.strip(),"value":v.strip()})
    return out

payload_servers=[]
for s in sorted(servers, key=lambda x:int(x.get("sort_order",0) or 0)):
    ps=ports(s.get("ports","53"))
    payload_servers.append({
        "name":str(s.get("name","")),
        "ip_addr":str(s.get("ip_addr","")),
        "domain":str(s.get("domain","")),
        "flag":str(s.get("flag","")),
        "ovpn_key":str(s.get("ovpn_key","")),
        "ovpn_options":str(s.get("ovpn_options","")),
        "port":ps,
        "info":info(s.get("info","")),
        "protocol":[{"type":p,"port":ps} for p in protocols(s.get("protocols","F"))]
    })

payload={
    "server_data_version":str(repo.get("version","1")),
    "release_timestamp":int(time.time()),
    "data_information":str(repo.get("data_information","")),
    "data_logo_image":str(repo.get("logo_image","")),
    "data_bottom_image":str(repo.get("bottom_image","")),
    "ads_disabled":bool(repo.get("ads_disabled",False)),
    "servers":payload_servers
}
json_bytes=json.dumps(payload,separators=(",",":"),ensure_ascii=False).encode("utf-8")

# Legacy client expects 16 filler bytes before the JSON after AES-CBC decrypt.
plaintext=b"\0"*16 + json_bytes
key_hex=key.hex()
iv_hex="00"*16

with tempfile.NamedTemporaryFile() as f:
    f.write(plaintext); f.flush()
    cmd=["openssl","enc","-aes-256-cbc","-K",key_hex,"-iv",iv_hex,"-in",f.name]
    enc=subprocess.run(cmd,check=True,capture_output=True).stdout
encoded=base64.b64encode(enc).decode("ascii")

(REPO_DIR / username).write_text(encoded+"\n",encoding="utf-8")
(DOCS / "repo" / f"{username}-check").write_text("OK\n",encoding="utf-8")

print(f"Generated docs/repo/{username}")
print(f"Servers: {len(payload_servers)}")
print(f"JSON bytes: {len(json_bytes)}")
