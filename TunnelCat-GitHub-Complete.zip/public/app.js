const DATA_URL = "../data/servers.json";
let data = {version:1,updatedAt:null,servers:[]};

const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

async function load(){
  try{
    const r=await fetch(DATA_URL+"?v="+Date.now(),{cache:"no-store"});
    if(!r.ok) throw new Error("Could not load server data.");
    data=await r.json();
    if(!Array.isArray(data.servers)) throw new Error("Invalid server data.");
    $("status").textContent="Online";
    render();
  }catch(e){
    $("status").textContent="Data error";
    $("servers").innerHTML='<div class="empty">'+esc(e.message)+'</div>';
  }
}

function render(){
  const s=data.servers;
  $("total").textContent=s.length;
  $("enabled").textContent=s.filter(x=>x.enabled).length;
  $("fastdns").textContent=s.filter(x=>x.protocol==="F_FAST_DNS").length;
  $("disabled").textContent=s.filter(x=>!x.enabled).length;

  const q=$("search").value.trim().toLowerCase();
  const list=s.filter(x=>
    !q ||
    String(x.name).toLowerCase().includes(q) ||
    String(x.ip).toLowerCase().includes(q) ||
    String(x.domain).toLowerCase().includes(q) ||
    String(x.country).toLowerCase().includes(q)
  );

  if(!list.length){
    $("servers").innerHTML='<div class="empty">No servers found.</div>';
    return;
  }

  $("servers").innerHTML=`<table>
  <thead><tr><th>Name</th><th>Endpoint</th><th>Protocol</th><th>Status</th><th>Country</th></tr></thead>
  <tbody>${list.map(x=>`<tr>
    <td><div class="name">${esc(x.name)}</div><div class="sub">${esc(x.id)}</div></td>
    <td>${esc(x.ip||x.domain||"")} : ${esc(x.port)}</td>
    <td><span class="badge">${esc(x.protocol)}</span></td>
    <td><span class="badge ${x.enabled?"on":"off"}">${x.enabled?"ENABLED":"DISABLED"}</span></td>
    <td>${esc(x.country||"")}</td>
  </tr>`).join("")}</tbody></table>`;
}

function openModal(){ $("modal").classList.add("show"); }
function closeModal(){ $("modal").classList.remove("show"); $("form").reset(); $("port").value=53; $("protocol").value="F_FAST_DNS"; $("enabled").checked=true; }

$("addTop").onclick=openModal;
$("close").onclick=closeModal;
$("cancel").onclick=closeModal;
$("search").oninput=render;

$("download").onclick=()=>{
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download="server_data.json";
  a.click();
  URL.revokeObjectURL(a.href);
};

$("form").onsubmit=e=>{
  e.preventDefault();

  const draft={
    id:$("id").value.trim(),
    name:$("name").value.trim(),
    enabled:$("enabled").checked,
    domain:$("domain").value.trim(),
    ip:$("ip").value.trim(),
    port:Number($("port").value),
    protocol:$("protocol").value,
    country:$("country").value.trim().toUpperCase(),
    flag:"",
    ovpnOption:$("ovpnOption").value,
    ovpnKey:$("ovpnKey").value,
    details:$("details").value.split("\n").map(x=>x.trim()).filter(Boolean)
  };

  if(!draft.id||!draft.name||!draft.ip){
    alert("ID, name and IP/host are required.");
    return;
  }

  if(data.servers.some(x=>x.id===draft.id)){
    alert("That server ID already exists.");
    return;
  }

  data.servers.unshift(draft);
  data.updatedAt=new Date().toISOString();
  closeModal();
  render();
  showToast("Draft added. Commit the updated data/servers.json to publish it.");
};

function showToast(text){
  $("toast").textContent=text;
  $("toast").classList.add("show");
  setTimeout(()=>$("toast").classList.remove("show"),3500);
}

load();
