# TunnelCat GitHub-only panel

## Deploy

1. Create a GitHub repository.
2. Upload this folder's contents.
3. Use `main` as the default branch.
4. Go to **Settings → Pages**.
5. Set **Source** to **GitHub Actions**.
6. The `Deploy TunnelCat Pages` workflow publishes `public/`.

Your site will be:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`

## Server data

The Android-facing catalogue is:

`data/servers.json`

Raw URL:

`https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-REPOSITORY/main/data/servers.json`

## Important

GitHub Pages is static. The Add Server form in the public page creates a local browser draft; it does not have permission to write to GitHub.

To permanently publish a server, edit/commit `data/servers.json` in GitHub (or use a separate authenticated GitHub workflow/admin mechanism).

Do not place private passwords, private keys, or other secrets in public `servers.json`.
